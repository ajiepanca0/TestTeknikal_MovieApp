package com.about.testteknikal.connection

import com.google.gson.annotations.SerializedName

data class ResponsePopular(
	val page: Int,
	val totalPages: Int,
	val results: List<ResultsItem>,
	val totalResults: Int
)

data class ResultsItem(
	val overview: String,
	val title: String,
	@field:SerializedName("poster_path")
	val posterPath: String,
	@field:SerializedName("release_date")
	val releaseDate: String,
	@field:SerializedName("popularity")
	val popularity: Double,
	@field:SerializedName("vote_average")
	val voteAverage: Double,
	val id: Int,

)

