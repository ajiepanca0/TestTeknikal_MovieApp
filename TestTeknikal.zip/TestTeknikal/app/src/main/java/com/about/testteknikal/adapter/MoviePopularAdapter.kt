package com.about.testteknikal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.about.testteknikal.R
import com.about.testteknikal.model.DataPopular
import com.bumptech.glide.Glide
import java.util.ArrayList

class MoviePopularAdapter(private val listMoviee: ArrayList<DataPopular>): RecyclerView.Adapter<MoviePopularAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.layout_itempopular, viewGroup, false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val(urlimage) = listMoviee[position]


        Glide.with(viewHolder.itemView.context)
            .load("https://image.tmdb.org/t/p/w500$urlimage")
            .into(viewHolder.itemimage)

        viewHolder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listMoviee[viewHolder.adapterPosition]) }

    }

    override fun getItemCount(): Int {
        return listMoviee.size
    }

    class ViewHolder (view : View) : RecyclerView.ViewHolder(view){

        val itemimage : ImageView = view.findViewById(R.id.imgPopular)


    }

    private lateinit var onItemClickCallback: OnItemClickCallback
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: DataPopular)
    }
}