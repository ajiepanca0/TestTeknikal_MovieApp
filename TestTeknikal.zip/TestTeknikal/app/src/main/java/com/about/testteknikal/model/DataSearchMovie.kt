package com.about.testteknikal.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DataSearchMovie (

    var id : Int ?,
    var title : String ?,
    var overview : String ?,
    var dataimage : String ?,
    var relasedate : String ?,
    var rate : Double ?,
    var popularity : Double ?
        ) : Parcelable