package com.about.testteknikal.connection

import com.google.gson.annotations.SerializedName

data class ResponseReviews(
	val id: Int,
	val page: Int,
	val totalPages: Int,
	val results: List<ResultsReviews>,
	val totalResults: Int
)

data class ResultsReviews(
	val authorDetails: AuthorDetails,
	val updatedAt: String,
	val author: String,
	@field:SerializedName("created_at")
	val createdAt: String,
	val id: String,
	val content: String,
	val url: String
)

data class AuthorDetails(
	val avatarPath: String,
	val name: String,
	val rating: Any,
	val username: String
)

