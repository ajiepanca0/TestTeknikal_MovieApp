package com.about.testteknikal.activitiy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.about.testteknikal.adapter.MovieSearchAdapter
import com.about.testteknikal.connection.ResponseSearchMovie
import com.about.testteknikal.connection.SearchResults
import com.about.testteknikal.connection.api.ApiConfig
import com.about.testteknikal.databinding.ActivitySearchMovieBinding
import com.about.testteknikal.model.DataKey
import com.about.testteknikal.model.DataMovie
import com.about.testteknikal.model.DataSearchMovie
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchMovieActivity : AppCompatActivity() {

    companion object{
        const val keysearhmovie= "query"
    }

    private lateinit var binding: ActivitySearchMovieBinding
    private lateinit var dataKey: DataKey

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchMovieBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val query = intent.getStringExtra(keysearhmovie)
        dataKey = DataKey()
        getData(query)
    }


    private fun shownotfound(film: Boolean) {
        if (film) {
            binding.notfound.visibility = View.VISIBLE
            binding.progresbar.visibility = View.VISIBLE
        } else {
            binding.progresbar.visibility = View.GONE
            binding.notfound.visibility = View.GONE
        }
    }

    private fun getData(query: String?) {
        val client = ApiConfig.getApiService().getSearchMovie(dataKey.keytmdb,query.toString())
        client.enqueue(object : Callback<ResponseSearchMovie>{
            override fun onResponse(
                call: Call<ResponseSearchMovie>,
                response: Response<ResponseSearchMovie>
            ) {
                if (response.isSuccessful){
                    val responseBody = response.body()
                    if (responseBody != null){
                        if (responseBody.results.isEmpty()){
                            shownotfound(true)
                        }else{
                            shownotfound(false)
                        setData(responseBody.results)
                        }
                    }else{
                        Toast.makeText(applicationContext, "Pencarian Tidak Ditemukan", Toast.LENGTH_SHORT).show()
                    }
                }else{
                    Toast.makeText(applicationContext, "Respon Failed", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseSearchMovie>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_SHORT).show()
            }

        })
    }

    private fun setData(results: List<SearchResults>) {

        if(results.isEmpty()){
            Toast.makeText(applicationContext, "null", Toast.LENGTH_SHORT).show()
        }else {


            val listsearchmoview = ArrayList<DataSearchMovie>()



            for (datasearchmovie in results) {
                val searchresultmoview = DataSearchMovie(
                    datasearchmovie.id,
                    datasearchmovie.title,
                    datasearchmovie.overview,
                    datasearchmovie.posterPath,
                    datasearchmovie.releaseDate,
                    datasearchmovie.voteAverage,
                    datasearchmovie.popularity
                )
                listsearchmoview.add(searchresultmoview)
            }

            val layoutManager = LinearLayoutManager(this)
            binding.rvSearchmovie.layoutManager = layoutManager
            val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
            binding.rvSearchmovie.addItemDecoration(itemDecoration)


            val adapter = MovieSearchAdapter(listsearchmoview)
            binding.rvSearchmovie.adapter = adapter


            adapter.setOnItemClickCallback(object : MovieSearchAdapter.OnItemClickCallback {
                override fun onItemClicked(data: DataSearchMovie) {
                    movetoDetail(data)

                }
            })
        }
    }
    private fun movetoDetail(data: DataSearchMovie) {

        val detail = DataMovie(
            data.id,
            data.title,
            data.overview,
            data.dataimage,
            data.relasedate,
            data.rate,
            data.popularity
        )

        val move = Intent(this,DetailMovieActivity::class.java)
        move.putExtra(DetailMovieActivity.detailMovie,detail)
        startActivity(move)

    }

}