package com.about.testteknikal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.about.testteknikal.R
import com.about.testteknikal.model.DataSearchMovie
import com.bumptech.glide.Glide
import java.util.ArrayList

class MovieSearchAdapter(private val listMoviee : ArrayList<DataSearchMovie>): RecyclerView.Adapter<MovieSearchAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.layout_itemsearchmovie, viewGroup, false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val(id,title,overview,urlimage,relasedate,rating) = listMoviee[position]

        viewHolder.itemid.text = id.toString()
        viewHolder.itemtitle.text = title
        viewHolder.itemoverview.text = overview
        Glide.with(viewHolder.itemView.context)
            .load("https://image.tmdb.org/t/p/w500$urlimage")
            .into(viewHolder.itemimage)
        viewHolder.itemrelase.text = relasedate
        viewHolder.itemrating.text = rating.toString()



        viewHolder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listMoviee[viewHolder.adapterPosition]) }



    }

    override fun getItemCount(): Int {
        return listMoviee.size
    }

    class ViewHolder (view : View) : RecyclerView.ViewHolder(view){
        val itemid : TextView = view.findViewById(R.id.idMovie)
        val itemtitle : TextView = view.findViewById(R.id.judulmovie)
        val itemrelase : TextView = view.findViewById(R.id.relaseMovie)
        val itemimage : ImageView = view.findViewById(R.id.imageMovie)
        val itemoverview : TextView = view.findViewById(R.id.overviewMovie)
        val itemrating : TextView = view.findViewById(R.id.ratingMovie)

    }

    private lateinit var onItemClickCallback: OnItemClickCallback
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: DataSearchMovie)
    }
}