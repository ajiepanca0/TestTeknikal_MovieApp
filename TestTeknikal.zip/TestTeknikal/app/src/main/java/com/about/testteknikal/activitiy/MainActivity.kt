package com.about.testteknikal.activitiy

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.about.testteknikal.adapter.MovieAdapter
import com.about.testteknikal.adapter.MoviePopularAdapter
import com.about.testteknikal.adapter.MovieupcomingAdapter
import com.about.testteknikal.connection.*
import com.about.testteknikal.connection.api.ApiConfig
import com.about.testteknikal.connection.ResponseMovieUpComing
import com.about.testteknikal.connection.ResultsItem
import com.about.testteknikal.connection.ResultsItemUpComing
import com.about.testteknikal.model.DataPopular
import com.about.testteknikal.databinding.ActivityMainBinding
import com.about.testteknikal.model.DataKey
import com.about.testteknikal.model.DataMovie
import com.about.testteknikal.model.DataUpcoming
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var datakey: DataKey

    private var listPopular =ArrayList<DataPopular>()
    private var listUpComing = ArrayList<DataUpcoming>()
    private var listMovie = ArrayList<DataMovie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        datakey = DataKey()


        getDataPopular()
        getDataUpcoming()
        getDataMovie()


        binding.searchMovie.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchKeymovie(query)
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                return false

            }
        })

    }





    private fun showLoadingUpcoming(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBarUpcoming.visibility = View.VISIBLE
        } else {
            binding.progressBarUpcoming.visibility = View.GONE
        }
    }


    private fun showLoadingPopular(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBarPopular.visibility = View.VISIBLE
        } else {
            binding.progressBarPopular.visibility = View.GONE
        }
    }

    private fun searchKeymovie(query: String?) {
        val movetoSearchmoview = Intent(this,SearchMovieActivity::class.java)
        movetoSearchmoview.putExtra(SearchMovieActivity.keysearhmovie,query)
        startActivity(movetoSearchmoview)
    }



    private fun getDataUpcoming() {
        showLoadingUpcoming(true)
        val dataUpComing = ApiConfig.getApiService().getMovieUpComing(datakey.keytmdb)
        dataUpComing.enqueue(object : Callback<ResponseMovieUpComing>{
            override fun onResponse(
                call: Call<ResponseMovieUpComing>,
                response: Response<ResponseMovieUpComing>
            ) {
                if (response.isSuccessful){
                    val responBody = response.body()
                    if (responBody != null){
                        showLoadingUpcoming(false)
                        setDataUpcoming(responBody.results)
                    }else{
                        Toast.makeText(applicationContext, "null", Toast.LENGTH_SHORT).show()
                    }
                }else{
                    Toast.makeText(applicationContext, "respon pailed", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseMovieUpComing>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun getDataMovie() {
        showLoadingPopular(true)
        val client = ApiConfig.getApiService().getMovie(datakey.keytmdb)
        client.enqueue(object : Callback<ResponseMovies> {
            override fun onResponse(
                call: Call<ResponseMovies>,
                response: Response<ResponseMovies>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        showLoadingPopular(false)
                        setDataMovie(responseBody.cast)
                    }else{
                        Toast.makeText(applicationContext, "null", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                    Toast.makeText(applicationContext, response.message(), Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<ResponseMovies>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun getDataPopular() {
        showLoadingPopular(true)
        val client = ApiConfig.getApiService().getMoviePopular(datakey.keytmdb)
        client.enqueue(object : Callback<ResponsePopular> {
            override fun onResponse(
                call: Call<ResponsePopular>,
                response: Response<ResponsePopular>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        showLoadingPopular(false)
                        setDataPopular(responseBody.results)
                    }else{
                        Toast.makeText(applicationContext, "null", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                    Toast.makeText(applicationContext, response.message(), Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<ResponsePopular>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun setDataMovie(movie: List<CastItem>) {

        for (review in movie){

            val mov = DataMovie(review.id, review.title, review.overview, review.posterPath,review.releaseDate, review.voteAverage, review.popularity)
            listMovie.add(mov)

        }

        val adapter = MovieAdapter(listMovie)
        binding.rvMovie.adapter = adapter

        val layoutManager = LinearLayoutManager(this)
        binding.rvMovie.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvMovie.addItemDecoration(itemDecoration)

        adapter.setOnItemClickCallback(object : MovieAdapter.OnItemClickCallback{
            override fun onItemClicked(data: DataMovie) {

                Toast.makeText(this@MainActivity, data.title, Toast.LENGTH_SHORT).show()
                detailMovieRekomend(data)
            }

        })



    }
    private fun setDataUpcoming(data: List<ResultsItemUpComing>) {

        for (upcoming in data){
            val movupcoming = DataUpcoming(  upcoming.posterPath, upcoming.id, upcoming.title, upcoming.overview,upcoming.releaseDate, upcoming.voteAverage, upcoming.popularity)
            listUpComing.add(movupcoming)
        }

        val adapterupcoming = MovieupcomingAdapter(listUpComing)

        binding.rvUpComing.layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        binding.rvUpComing.adapter = adapterupcoming

        adapterupcoming.setOnItemClickCallback(object : MovieupcomingAdapter.OnItemClickCallback{
            override fun onItemClicked(data: DataUpcoming) {

                detailMovieUpComing(data)

            }
        })
    }
    private fun setDataPopular(itemMov: List<ResultsItem>) {

        for (review in itemMov) {

            val mov = DataPopular(
                review.posterPath,
                review.id,
                review.title,
                review.overview,
                review.releaseDate,
                review.voteAverage,
                review.popularity
            )
            listPopular.add(mov)

        }

        val adapterpopular = MoviePopularAdapter(listPopular)

        binding.rvMoviePopular.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvMoviePopular.adapter = adapterpopular

        adapterpopular.setOnItemClickCallback(object : MoviePopularAdapter.OnItemClickCallback {
            override fun onItemClicked(data: DataPopular) {

                Toast.makeText(applicationContext, "Berhasil", Toast.LENGTH_SHORT).show()
                detailMoviePopular(data)

            }
        })
    }

    private fun detailMoviePopular(data: DataPopular) {

        val detail = DataMovie(
            data.id,
            data.title,
            data.overview,
            data.dataimage,
            data.relasedate,
            data.rate,
            data.popularity
        )

        val move = Intent(this,DetailMovieActivity::class.java)
        move.putExtra(DetailMovieActivity.detailMovie,detail)
        startActivity(move)


    }
    private fun detailMovieRekomend(data: DataMovie) {

        val detail = DataMovie(
            data.id,
            data.title,
            data.overview,
            data.dataimage,
            data.relasedate,
            data.rate,
            data.popularity
        )

        val move = Intent(this,DetailMovieActivity::class.java)
        move.putExtra(DetailMovieActivity.detailMovie,detail)
        startActivity(move)
    }
    private fun detailMovieUpComing(data: DataUpcoming) {

        val detail = DataMovie(
            data.id,
            data.title,
            data.overview,
            data.dataimage,
            data.relasedate,
            data.rate,
            data.popularity
        )

        val move = Intent(this,DetailMovieActivity::class.java)
        move.putExtra(DetailMovieActivity.detailMovie,detail)
        startActivity(move)    }
}

