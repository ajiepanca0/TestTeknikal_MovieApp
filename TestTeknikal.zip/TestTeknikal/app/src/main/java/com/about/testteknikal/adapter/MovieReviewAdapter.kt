package com.about.testteknikal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.about.testteknikal.R
import com.about.testteknikal.model.DataReview
import java.util.ArrayList

class MovieReviewAdapter(private val listMoviee : ArrayList<DataReview>): RecyclerView.Adapter<MovieReviewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.layout_itemreviewmovie, viewGroup, false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val(id,author,content,createdat) = listMoviee[position]

        viewHolder.itemid.text = id
        viewHolder.itemauthor.text = author
        viewHolder.itemcontent.text = content
        viewHolder.itemcreatedat.text = createdat


        viewHolder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listMoviee[viewHolder.adapterPosition]) }



    }

    override fun getItemCount(): Int {
        return listMoviee.size
    }

    class ViewHolder (view : View) : RecyclerView.ViewHolder(view){
        val itemid : TextView = view.findViewById(R.id.idreviewmovie)
        val itemauthor : TextView = view.findViewById(R.id.authorreview)
        val itemcontent : TextView = view.findViewById(R.id.contentreviewmovie)
        val itemcreatedat : TextView = view.findViewById(R.id.createdatreview)

    }

    private lateinit var onItemClickCallback: OnItemClickCallback
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: DataReview)
    }
}