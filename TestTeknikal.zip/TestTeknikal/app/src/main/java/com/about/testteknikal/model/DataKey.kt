package com.about.testteknikal.model



class DataKey (

    val keytmdb: String = "7fd85d1ae16130aa2bbe3d705027b5be",
    val youtubeKey : String = "AIzaSyAuZXLvMiDCjU-gj1x_5IrFLrF6JhxnNRo"

)

