package com.about.testteknikal.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DataReview(

    var id: String ?,
    var author: String ?,
    var content: String ?,
    var created_at: String ?
) : Parcelable