package com.about.testteknikal.connection

import com.google.gson.annotations.SerializedName

data class ResponseKey(

	@field:SerializedName("id")
	val id: Int,

	@field:SerializedName("results")
	val results: List<ResultsItemm>
)

data class ResultsItemm(

	@field:SerializedName("id")
	val id: String,

	@field:SerializedName("key")
	val key: String
)
