package com.about.testteknikal.connection.api

import com.about.testteknikal.connection.*
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiInterfaces {

    @GET("3/movie/popular")
    fun getMoviePopular( @Query("api_key") keyy: String): Call<ResponsePopular>

    @GET("3/person/287/movie_credits")
    fun getMovie( @Query("api_key") keyy: String): Call<ResponseMovies>

    @GET("3/movie/upcoming")
    fun getMovieUpComing( @Query("api_key") keyy: String): Call<ResponseMovieUpComing>

   @GET("3/movie/{id}/videos")
    fun getKeyMovie(@Path("id") id: String,
                       @Query("api_key") keyy: String
                        ): Call<ResponseKey>


    @GET("3/search/movie")
    fun getSearchMovie( @Query("api_key") keyy: String,
                        @Query("query") query : String): Call<ResponseSearchMovie>

    @GET("3/movie/{id}/reviews")
    fun getReviewMovie(@Path("id") id: String,
                       @Query("api_key") keyy: String): Call<ResponseReviews>


}