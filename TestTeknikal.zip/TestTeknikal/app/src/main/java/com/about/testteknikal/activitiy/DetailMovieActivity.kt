package com.about.testteknikal.activitiy
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.about.testteknikal.adapter.MovieReviewAdapter
import com.about.testteknikal.connection.ResponseKey
import com.about.testteknikal.connection.ResponseReviews
import com.about.testteknikal.connection.ResultsItemm
import com.about.testteknikal.connection.ResultsReviews
import com.about.testteknikal.connection.api.ApiConfig
import com.about.testteknikal.databinding.ActivityDetailMovieBinding
import com.about.testteknikal.model.DataKey
import com.about.testteknikal.model.DataMovie
import com.about.testteknikal.model.DataReview
import com.bumptech.glide.Glide
import com.google.android.youtube.player.YouTubeBaseActivity
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.ArrayList

class DetailMovieActivity : YouTubeBaseActivity() {

    private var id = ""
    private var listReviews = ArrayList<DataReview>()
    private lateinit var datakey: DataKey
    private lateinit var youtubePlayerInit : YouTubePlayer.OnInitializedListener
    private lateinit var binding: ActivityDetailMovieBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailMovieBinding.inflate(layoutInflater)
        setContentView(binding.root)

        datakey = DataKey()

        val data = intent.getParcelableExtra(detailMovie) as? DataMovie

            binding.titledetailmovie.text = data?.title
            Glide.with(this)
                .load("https://image.tmdb.org/t/p/w500" + data?.dataimage)
                .into(binding.imagedetailMovie)
            binding.overviewdetailmovie.text = data?.overview
            binding.relasedetailmovie.text = data?.relasedate
            binding.ratingdetailmovie.text = data?.rate.toString()
            id = data?.id.toString()
            binding.popularitydetailmovie.text = data?.popularity.toString()




        getKey(id,datakey.keytmdb)
        getReviewMovie(id,datakey.keytmdb)

    }

    private fun showLoadingReview(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBarReview.visibility = View.VISIBLE
            binding.rvReview.visibility = View.GONE
        } else {
            binding.progressBarReview.visibility = View.GONE
            binding.rvReview.visibility = View.VISIBLE
        }
    }


    private fun getReviewMovie(id: String, keytmdb: String) {
        showLoadingReview(true)
        val client = ApiConfig.getApiService().getReviewMovie(id, keytmdb)
        client.enqueue(object : Callback<ResponseReviews>{
            override fun onResponse(
                call: Call<ResponseReviews>,
                response: Response<ResponseReviews>
            ) {
                if (response.isSuccessful) {
                    val respon = response.body()
                    if (respon != null) {
                        if (respon.results.isEmpty()){
                            showLoadingReview(false)
                            Toast.makeText(applicationContext, "NOT REVIEW", Toast.LENGTH_SHORT).show()
                        }else{
                            showLoadingReview(false)
                            setReview(respon.results)
                        }

                    }
                }
            }

            override fun onFailure(call: Call<ResponseReviews>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }

        })
    }


    private fun getKey(id: String, keytmdb: String) {
                val client = ApiConfig.getApiService().getKeyMovie(id, keytmdb)
                client.enqueue(object : Callback<ResponseKey>{
                    override fun onResponse(
                        call: Call<ResponseKey>,
                        response: Response<ResponseKey>
                    ) {
                        if (response.isSuccessful) {
                            val respon = response.body()
                            if (respon != null) {
                                if (respon.results.isEmpty()){
                                    Toast.makeText(applicationContext, "NOT THIALER", Toast.LENGTH_SHORT).show()
                                }else{
                                keyMovie(respon.results) }

                            }
                        }
                    }

                    override fun onFailure(call: Call<ResponseKey>, t: Throwable) {
                        Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
                    }

                })
    }

    private fun keyMovie(keyMov: List<ResultsItemm>) {

        val keyMovie = keyMov[0].key

            youtubePlayerInit = object : YouTubePlayer.OnInitializedListener {
                override fun onInitializationSuccess(
                    p0: YouTubePlayer.Provider?,
                    p1: YouTubePlayer?,
                    p2: Boolean
                ) {
                    p1?.loadVideo(keyMovie)
                    p1?.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT)
                }

                override fun onInitializationFailure(
                    p0: YouTubePlayer.Provider?,
                    p1: YouTubeInitializationResult?
                ) {
                    Toast.makeText(applicationContext, "Failed", Toast.LENGTH_SHORT).show()
                }
            }

            binding.youtubePlayer.initialize(datakey.youtubeKey, youtubePlayerInit)
        }


    private fun setReview(results: List<ResultsReviews>) {


        for (review in results){

            val mov = DataReview(review.id, review.author, review.content, review.createdAt)
            listReviews.add(mov)

        }

        val adapter = MovieReviewAdapter(listReviews)
        binding.rvReview.adapter = adapter

        val layoutManager = LinearLayoutManager(this)
        binding.rvReview.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvReview.addItemDecoration(itemDecoration)

        adapter.setOnItemClickCallback(object : MovieReviewAdapter.OnItemClickCallback{
            override fun onItemClicked(data: DataReview) {

                Toast.makeText(this@DetailMovieActivity, data.author, Toast.LENGTH_SHORT).show()
            }

        })


    }

    companion object{
        const val detailMovie= "detail"
    }


}




