package com.about.testteknikal.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class DataUpcoming (

    var dataimage : String ?,
    var id : Int ?,
    var title : String ?,
    var overview : String ?,
    var relasedate : String ?,
    var rate : Double ?,
    var popularity : Double ?
) : Parcelable